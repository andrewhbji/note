package com.itic.mobile.net;

@Deprecated
public enum HttpMethod {
	GET,POST
}
