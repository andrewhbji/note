package com.example.andrea.demologin;


public class Config {
    public static final String ACCOUNT_TYPE = "com.example.andrea.demologin.account";
}
